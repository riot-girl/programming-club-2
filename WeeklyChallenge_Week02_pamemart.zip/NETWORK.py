network = {
    'RA' : ['R_Nextengo','R_SantaFe'],
    'R_Nextengo' : ['SW_Tlalnepantla', 'SW_Toluca'],
    'R_SantaFe' : ['SW_Cuajimalpa'],
    'SW_Tlalnepantla' : ['Terminal_Naucalpan'],
    'SW_Toluca' : ['Terminal_Metepec'],
    'SW_Cuajimalpa' : ['Terminal_DesiertoLeones'],
    'Terminal_Naucalpan' : [],
    'Terminal_Metepec' : [],
    'Terminal_DesiertoLeones' : []
}